import { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  Play, Zap, ChevronRight,
  Star, TrendingUp, Users, ArrowRight, Sparkles
} from 'lucide-react';
import DaysCounter from '../components/DaysCounter';

// ─── Particles Background ───────────────────────────────────────────────────
function Particles() {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {Array.from({ length: 20 }).map((_, i) => (
        <div
          key={i}
          className="absolute rounded-full opacity-20"
          style={{
            width: Math.random() * 4 + 2 + 'px',
            height: Math.random() * 4 + 2 + 'px',
            left: Math.random() * 100 + '%',
            top: Math.random() * 100 + '%',
            background: i % 2 === 0 ? '#dc2626' : '#f97316',
            animation: `particle ${Math.random() * 10 + 8}s linear ${Math.random() * 5}s infinite`,
          }}
        />
      ))}
    </div>
  );
}

// ─── Animated Background Grid ────────────────────────────────────────────────
function HeroBackground() {
  return (
    <div className="absolute inset-0 overflow-hidden">
      <div
        className="absolute inset-0"
        style={{
          backgroundImage: `url('/images/hero-bg.jpg')`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          opacity: 0.25,
        }}
      />
      {/* Grid overlay */}
      <div className="absolute inset-0 bg-grid opacity-40" />
      {/* Gradient overlays */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#0a0a0f] via-transparent to-[#0a0a0f]" />
      <div className="absolute inset-0 bg-gradient-to-r from-[#0a0a0f] via-transparent to-[#0a0a0f]" />
      {/* Red glow spots */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-red-600/10 rounded-full blur-3xl" />
      <div className="absolute bottom-1/4 right-1/4 w-64 h-64 bg-orange-500/10 rounded-full blur-3xl" />
      <Particles />
    </div>
  );
}

// ─── Feature Card ────────────────────────────────────────────────────────────
interface FeatureCardProps {
  emoji: string;
  title: string;
  description: string;
  color: string;
  delay?: number;
}

function FeatureCard({ emoji, title, description, color, delay = 0 }: FeatureCardProps) {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setVisible(true); },
      { threshold: 0.1 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  return (
    <div
      ref={ref}
      className="feature-card rounded-2xl p-6 cursor-default"
      style={{
        transition: `all 0.6s ease ${delay}ms`,
        opacity: visible ? 1 : 0,
        transform: visible ? 'translateY(0)' : 'translateY(30px)',
      }}
    >
      <div className={`w-12 h-12 rounded-xl flex items-center justify-center text-2xl mb-4 ${color}`}>
        {emoji}
      </div>
      <h3 className="text-white font-bold text-lg mb-2" style={{ fontFamily: 'Space Grotesk, sans-serif' }}>
        {title}
      </h3>
      <p className="text-white/50 text-sm leading-relaxed">{description}</p>
    </div>
  );
}

// ─── Stats Card ──────────────────────────────────────────────────────────────
function StatCard({ value, label, icon }: { value: string; label: string; icon: React.ReactNode }) {
  return (
    <div className="stat-card rounded-2xl px-6 py-5 text-center flex flex-col items-center gap-2 card-hover">
      <div className="text-red-400 mb-1">{icon}</div>
      <div className="text-3xl font-black gradient-text" style={{ fontFamily: 'Space Grotesk, sans-serif' }}>
        {value}
      </div>
      <div className="text-white/50 text-sm tracking-wider uppercase font-medium">{label}</div>
    </div>
  );
}

// ─── Main Home Page ───────────────────────────────────────────────────────────
export default function Home() {
  const [typedText, setTypedText] = useState('');
  const fullText = 'Aaba Ramilo Suru';

  useEffect(() => {
    let i = 0;
    const timer = setInterval(() => {
      if (i <= fullText.length) {
        setTypedText(fullText.slice(0, i));
        i++;
      } else {
        clearInterval(timer);
      }
    }, 80);
    return () => clearInterval(timer);
  }, []);

  const features = [
    {
      emoji: '🎬',
      title: 'Short Videos',
      description: 'Create and share 15s to 60s videos with filters, effects, and music. Express yourself the Nepali way.',
      color: 'bg-red-600/20 border border-red-600/20',
    },
    {
      emoji: '📡',
      title: 'Live Streaming',
      description: 'Go live and connect with your audience in real-time. Receive gifts and build your Nepali community.',
      color: 'bg-orange-500/20 border border-orange-500/20',
    },
    {
      emoji: '💰',
      title: 'Earn Rewards',
      description: 'Creators earn coins from gifts, which can be converted to real money. Your content has real value.',
      color: 'bg-yellow-500/20 border border-yellow-500/20',
    },
    {
      emoji: '🎵',
      title: 'Nepali Sounds',
      description: 'A growing library of Nepali music and trending sounds. Create content that resonates with Nepal.',
      color: 'bg-purple-500/20 border border-purple-500/20',
    },
    {
      emoji: '🔒',
      title: 'Safe & Secure',
      description: 'Content moderation, reporting system, and privacy controls to keep the Nepali community safe.',
      color: 'bg-blue-500/20 border border-blue-500/20',
    },
    {
      emoji: '⚡',
      title: 'Fast & Light',
      description: 'Optimized for Nepal\'s network conditions. Works smoothly even on slower internet connections.',
      color: 'bg-green-500/20 border border-green-500/20',
    },
  ];

  return (
    <div className="min-h-screen bg-[#0a0a0f]">
      {/* ─── HERO SECTION ──────────────────────────────────────────────── */}
      <section className="relative min-h-screen flex flex-col items-center justify-center px-4 pt-24 pb-12 overflow-hidden">
        <HeroBackground />

        <div className="relative z-10 max-w-5xl mx-auto text-center space-y-6">
          {/* Nepal badge */}
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/10 text-sm text-white/70 mb-4 flag-pulse">
            <span className="text-lg">🇳🇵</span>
            <span className="tracking-wider font-medium">Nepal's Own Platform</span>
            <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse ml-1" />
          </div>

          {/* ARS Logo mark */}
          <div className="flex justify-center mb-2">
            <div className="relative w-20 h-20 sm:w-24 sm:h-24 rounded-3xl bg-gradient-to-br from-red-600 to-orange-500 flex items-center justify-center shadow-2xl glow-red float">
              <Play className="w-10 h-10 sm:w-12 sm:h-12 text-white fill-white" />
              <div className="absolute -top-2 -right-2 w-5 h-5 bg-red-400 rounded-full border-2 border-[#0a0a0f] animate-pulse" />
            </div>
          </div>

          {/* Brand name */}
          <div>
            <h1
              className="text-5xl sm:text-6xl md:text-7xl lg:text-8xl font-black tracking-tight text-white"
              style={{ fontFamily: 'Space Grotesk, sans-serif' }}
            >
              <span className="gradient-text">ARS</span>
            </h1>
            <h2
              className="text-xl sm:text-2xl md:text-3xl font-bold text-white/80 mt-2 min-h-[2.5rem]"
              style={{ fontFamily: 'Space Grotesk, sans-serif' }}
            >
              {typedText}
              <span className="cursor text-red-400 font-thin">|</span>
            </h2>
          </div>

          {/* Tagline */}
          <p className="text-base sm:text-lg md:text-xl text-white/60 max-w-2xl mx-auto leading-relaxed font-light">
            Nepal's own short-form video social media platform — built by a Nepali student for Nepali creators.
            <span className="text-red-400 font-medium"> Express yourself, go viral, earn rewards.</span>
          </p>

          {/* CTA Line */}
          <div className="flex flex-wrap justify-center gap-2 text-lg sm:text-xl font-bold">
            {['Create.', 'Share.', 'Inspire Nepal.'].map((word, i) => (
              <span
                key={word}
                className={i === 2 ? 'gradient-text' : 'text-white/90'}
                style={{ fontFamily: 'Space Grotesk, sans-serif' }}
              >
                {word}
              </span>
            ))}
          </div>

          {/* Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-2">
            <a
              href="#join"
              className="btn-primary px-8 py-4 rounded-2xl text-base font-bold text-white flex items-center gap-2 shadow-xl"
            >
              <span>🚀 Join Waitlist</span>
              <ArrowRight className="w-4 h-4" />
            </a>
            <Link
              to="/products"
              className="btn-secondary px-8 py-4 rounded-2xl text-base font-bold text-white flex items-center gap-2"
            >
              <span>See Products</span>
              <ChevronRight className="w-4 h-4" />
            </Link>
          </div>

          {/* Scroll indicator */}
          <div className="pt-8 flex flex-col items-center gap-2 text-white/20">
            <span className="text-xs tracking-widest uppercase">Scroll to explore</span>
            <div className="w-5 h-8 border border-white/20 rounded-full flex items-start justify-center p-1">
              <div className="w-1 h-2 bg-red-400 rounded-full animate-bounce" />
            </div>
          </div>
        </div>
      </section>

      {/* ─── STATS SECTION ─────────────────────────────────────────────── */}
      <section className="relative py-16 px-4 bg-gradient-to-b from-[#0a0a0f] to-black/60">
        <div className="max-w-5xl mx-auto">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 sm:gap-6">
            {/* Live Days Counter */}
            <div className="stat-card rounded-2xl p-6 text-center card-hover col-span-1">
              <DaysCounter showLabel={true} />
            </div>

            <StatCard
              value="∞"
              label="Possibilities"
              icon={<Sparkles className="w-5 h-5" />}
            />
            <StatCard
              value="1"
              label="Developer"
              icon={<Star className="w-5 h-5" />}
            />
          </div>
        </div>
      </section>

      {/* ─── SECTION DIVIDER ───────────────────────────────────────────── */}
      <div className="section-divider mx-8 sm:mx-16 my-2" />

      {/* ─── FEATURES SECTION ──────────────────────────────────────────── */}
      <section id="features" className="relative py-20 px-4">
        <div className="max-w-6xl mx-auto">
          {/* Section header */}
          <div className="text-center mb-14">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-red-600/10 border border-red-600/20 text-red-400 text-sm font-medium mb-4">
              <Zap className="w-4 h-4" />
              Platform Features
            </div>
            <h2
              className="text-3xl sm:text-4xl md:text-5xl font-black text-white"
              style={{ fontFamily: 'Space Grotesk, sans-serif' }}
            >
              Everything Nepal{' '}
              <span className="gradient-text">Needs</span>
            </h2>
            <p className="text-white/50 mt-4 text-base max-w-xl mx-auto">
              Designed from scratch with Nepali creators in mind. Every feature built to serve the community.
            </p>
          </div>

          {/* Feature grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {features.map((f, i) => (
              <FeatureCard key={f.title} {...f} delay={i * 80} />
            ))}
          </div>
        </div>
      </section>

      {/* ─── PHONE MOCKUP / APP PREVIEW SECTION ────────────────────────── */}
      <section className="relative py-20 px-4 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-red-950/20 via-transparent to-orange-950/20" />
        <div className="max-w-6xl mx-auto relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            {/* Left: text */}
            <div className="space-y-6">
              <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-orange-500/10 border border-orange-500/20 text-orange-400 text-sm font-medium">
                <TrendingUp className="w-4 h-4" />
                Coming Soon
              </div>
              <h2
                className="text-3xl sm:text-4xl md:text-5xl font-black text-white leading-tight"
                style={{ fontFamily: 'Space Grotesk, sans-serif' }}
              >
                The Next-Gen<br />
                <span className="gradient-text">Nepali App</span>
              </h2>
              <p className="text-white/50 text-base leading-relaxed">
                ARS is being built from the ground up — optimized for mobile-first Nepal.
                A platform that truly understands the Nepali creator, their language, their culture, their dreams.
              </p>

              <div className="space-y-3">
                {[
                  { icon: '🎬', text: 'Short videos 15s – 60s with Nepali filters' },
                  { icon: '📡', text: 'Live streaming with gift economy' },
                  { icon: '💰', text: 'Monetization for Nepali creators' },
                  { icon: '🇳🇵', text: 'Fully localized for Nepal' },
                ].map((item) => (
                  <div key={item.text} className="flex items-center gap-3 text-white/70">
                    <span className="text-lg w-8">{item.icon}</span>
                    <span className="text-sm">{item.text}</span>
                  </div>
                ))}
              </div>

              <Link
                to="/products"
                className="inline-flex items-center gap-2 btn-primary px-7 py-3.5 rounded-2xl text-sm font-bold text-white"
              >
                <span>Explore All Products</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>

            {/* Right: phone mockup */}
            <div className="flex justify-center">
              <div className="relative float">
                <div
                  className="w-52 sm:w-64 rounded-[3rem] overflow-hidden border-4 border-white/10 shadow-2xl"
                  style={{
                    boxShadow: '0 0 60px rgba(220,38,38,0.3), 0 40px 80px rgba(0,0,0,0.6)',
                  }}
                >
                  <img
                    src="/images/phone-mockup.png"
                    alt="ARS App Mockup"
                    className="w-full h-auto"
                  />
                </div>
                {/* Floating badges */}
                <div className="absolute -top-4 -right-4 bg-gradient-to-r from-red-600 to-orange-500 text-white text-xs font-bold px-3 py-1.5 rounded-full shadow-lg float-delayed">
                  🇳🇵 Nepal's Own
                </div>
                <div className="absolute -bottom-4 -left-4 bg-[#1a1a2e] border border-white/10 text-white text-xs font-medium px-3 py-1.5 rounded-full shadow-lg float-delayed">
                  ⚡ Coming Soon
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ─── ABOUT DEVELOPER ────────────────────────────────────────────── */}
      <section id="about" className="relative py-20 px-4 bg-gradient-to-b from-black/20 to-[#0a0a0f]">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-purple-600/10 border border-purple-600/20 text-purple-400 text-sm font-medium mb-4">
              <Users className="w-4 h-4" />
              The Developer
            </div>
            <h2
              className="text-3xl sm:text-4xl md:text-5xl font-black text-white"
              style={{ fontFamily: 'Space Grotesk, sans-serif' }}
            >
              Built by a{' '}
              <span className="gradient-text">Nepali Student</span>
            </h2>
          </div>

          {/* Developer card */}
          <div className="relative bg-gradient-to-br from-white/5 to-white/[0.02] border border-white/10 rounded-3xl p-8 sm:p-10 overflow-hidden card-hover">
            {/* Background decoration */}
            <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-bl from-red-600/10 to-transparent rounded-full blur-2xl" />
            <div className="absolute bottom-0 left-0 w-48 h-48 bg-gradient-to-tr from-orange-500/10 to-transparent rounded-full blur-2xl" />

            <div className="relative z-10 flex flex-col sm:flex-row items-center sm:items-start gap-8">
              {/* Avatar */}
              <div className="relative flex-shrink-0">
                <div className="relative w-24 h-24 sm:w-28 sm:h-28 rounded-3xl overflow-hidden border-2 border-red-600/40 shadow-xl pulse-ring">
                  <img
                    src="/images/roshan-avatar.jpg"
                    alt="Roshan Shrestha"
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      e.currentTarget.style.display = 'none';
                      const parent = e.currentTarget.parentElement;
                      if (parent) {
                        parent.style.background = 'linear-gradient(135deg, #dc2626, #f97316)';
                        parent.style.display = 'flex';
                        parent.style.alignItems = 'center';
                        parent.style.justifyContent = 'center';
                        parent.innerHTML = '<span style="font-size:2.5rem;font-weight:900;color:white">R</span>';
                      }
                    }}
                  />
                </div>
                <div className="absolute -bottom-2 -right-2 bg-green-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-full border-2 border-[#0a0a0f]">
                  BUILDING
                </div>
              </div>

              {/* Info */}
              <div className="flex-1 text-center sm:text-left space-y-3">
                <div>
                  <h3
                    className="text-2xl sm:text-3xl font-black text-white"
                    style={{ fontFamily: 'Space Grotesk, sans-serif' }}
                  >
                    Roshan Shrestha{' '}
                    <span className="wave">👋</span>
                  </h3>
                  <p className="text-red-400 font-semibold text-sm mt-0.5">Developer & Founder @ ARS Nepal</p>
                </div>

                <p className="text-white/60 text-sm sm:text-base leading-relaxed max-w-xl">
                  A <span className="text-white font-semibold">17-year-old Class 9 student</span> from Nepal,
                  building his own social media network from scratch. Passionate about creating technology that
                  serves Nepali creators and brings the community together. Every line of code is written with
                  the dream of giving Nepal its own platform to shine.
                </p>

                {/* Tags */}
                <div className="flex flex-wrap justify-center sm:justify-start gap-2 pt-1">
                  {[
                    { emoji: '🎓', text: '17 yrs' },
                    { emoji: '📚', text: 'Class 9' },
                    { emoji: '🇳🇵', text: 'Nepal' },
                    { emoji: '💻', text: 'Self-taught' },
                    { emoji: '🚀', text: 'Founder' },
                  ].map((tag) => (
                    <span
                      key={tag.text}
                      className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-white/60 text-xs font-medium"
                    >
                      {tag.emoji} {tag.text}
                    </span>
                  ))}
                </div>

                {/* Days counter inline */}
                <div className="flex flex-wrap justify-center sm:justify-start gap-4 pt-2">
                  <div className="flex items-center gap-2 bg-red-600/10 border border-red-600/20 rounded-xl px-4 py-2">
                    <div className="w-2 h-2 rounded-full bg-red-400 animate-pulse" />
                    <span className="text-red-400 text-xs font-semibold">Actively building every day</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Quote */}
            <div className="relative z-10 mt-8 pt-6 border-t border-white/5">
              <blockquote className="text-center text-white/40 text-sm italic">
                "I'm just a student from Nepal, but I believe Nepal deserves its own platform.
                <span className="text-red-400 not-italic font-semibold"> Aaba Ramilo Suru.</span>"
              </blockquote>
              <p className="text-center text-white/20 text-xs mt-2">— Roshan Shrestha, Developer</p>
            </div>
          </div>
        </div>
      </section>

      {/* ─── CTA / JOIN SECTION ─────────────────────────────────────────── */}
      <section id="join" className="relative py-20 px-4">
        <div className="max-w-3xl mx-auto text-center space-y-8">
          <div className="relative bg-gradient-to-br from-red-950/40 to-orange-950/20 border border-red-600/20 rounded-3xl p-10 sm:p-14 overflow-hidden">
            {/* Glow */}
            <div className="absolute inset-0 bg-gradient-to-br from-red-600/5 to-orange-500/5" />
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-red-600/10 rounded-full blur-3xl" />

            <div className="relative z-10 space-y-6">
              <div className="text-5xl">🚀</div>
              <h2
                className="text-3xl sm:text-4xl md:text-5xl font-black text-white"
                style={{ fontFamily: 'Space Grotesk, sans-serif' }}
              >
                Be First in{' '}
                <span className="gradient-text">Nepal</span>
              </h2>
              <p className="text-white/50 text-base max-w-lg mx-auto">
                ARS is under construction. Join the waitlist and be among the first Nepali creators
                when we launch. Your creativity, your platform.
              </p>

              {/* Email form */}
              <div className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto">
                <input
                  type="email"
                  placeholder="your@email.com"
                  className="flex-1 px-5 py-3.5 rounded-xl bg-white/5 border border-white/15 text-white placeholder-white/30 text-sm focus:outline-none focus:border-red-600/60 focus:bg-white/8 transition-all"
                />
                <button className="btn-primary px-6 py-3.5 rounded-xl text-sm font-bold text-white whitespace-nowrap">
                  <span>Join Now 🇳🇵</span>
                </button>
              </div>

              <p className="text-white/20 text-xs">No spam. Only launch updates. Swear on Sagarmatha. 🏔️</p>
            </div>
          </div>
        </div>
      </section>

      {/* ─── FOOTER TAGLINE ─────────────────────────────────────────────── */}
      <div className="text-center py-8 px-4">
        <p className="text-white/30 text-sm">
          <span className="gradient-text font-semibold">Aaba Ramilo Suru</span>
          {' '}— Create. Share. Inspire.
        </p>
      </div>
    </div>
  );
}
