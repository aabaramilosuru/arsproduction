import { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, Zap, CheckCircle2, Clock, Rocket, Star, ArrowRight } from 'lucide-react';
import DaysCounter from '../components/DaysCounter';

// ─── Types ────────────────────────────────────────────────────────────────────
interface Product {
  id: string;
  emoji: string;
  name: string;
  tagline: string;
  description: string;
  status: 'building' | 'planned' | 'idea';
  features: string[];
  color: string;
  glowColor: string;
  tech: string[];
}

// ─── Product Data ──────────────────────────────────────────────────────────────
const products: Product[] = [
  {
    id: 'ars-app',
    emoji: '🎬',
    name: 'ARS Video App',
    tagline: "Nepal's TikTok Alternative",
    description:
      'The flagship short-form video platform for Nepali creators. Upload 15s–60s videos, add Nepali filters, trending sounds, and reach millions of Nepali viewers. Built for Nepal, by Nepal.',
    status: 'building',
    features: [
      'Short videos 15s – 60s',
      'Nepali filters & effects',
      'Trending Nepali sounds',
      'For You algorithm',
      'Creator analytics dashboard',
      'Comment & duet system',
    ],
    color: 'from-red-600/20 to-orange-600/10',
    glowColor: 'rgba(220, 38, 38, 0.3)',
    tech: ['React Native', 'Node.js', 'MongoDB', 'AWS S3'],
  },
  {
    id: 'ars-live',
    emoji: '📡',
    name: 'ARS Live',
    tagline: 'Real-Time Community Streaming',
    description:
      'Go live and connect directly with your Nepali audience. Accept virtual gifts, build a loyal fanbase, and turn your passion into income through real-time engagement.',
    status: 'planned',
    features: [
      'HD live streaming',
      'Virtual gift system',
      'Gift-to-coin conversion',
      'Real-time chat & reactions',
      'Co-host feature',
      'Replay recording',
    ],
    color: 'from-orange-600/20 to-yellow-600/10',
    glowColor: 'rgba(249, 115, 22, 0.3)',
    tech: ['WebRTC', 'Socket.io', 'Redis', 'FFmpeg'],
  },
  {
    id: 'ars-coins',
    emoji: '💰',
    name: 'ARS Coins & Rewards',
    tagline: 'Creator Monetization System',
    description:
      'A complete economy for creators. Earn coins through gifts and engagement, convert them to Nepali rupees, and withdraw directly to your bank or eSewa/Khalti wallet.',
    status: 'planned',
    features: [
      'Coin-to-NPR conversion',
      'eSewa & Khalti integration',
      'Bank transfer support',
      'Creator leaderboard',
      'Daily reward challenges',
      'Referral bonus system',
    ],
    color: 'from-yellow-600/20 to-green-600/10',
    glowColor: 'rgba(234, 179, 8, 0.3)',
    tech: ['eSewa API', 'Khalti API', 'Node.js', 'PostgreSQL'],
  },
  {
    id: 'ars-sounds',
    emoji: '🎵',
    name: 'ARS Sounds',
    tagline: 'Nepali Music Library',
    description:
      'A dedicated library of Nepali songs, folk music, trending sounds, and original creator-made audio. Use the perfect sound for your next viral video.',
    status: 'planned',
    features: [
      'Thousands of Nepali tracks',
      'Folk & modern music',
      'Original creator sounds',
      'Trending sounds chart',
      'Audio trimmer tool',
      'Royalty-free collection',
    ],
    color: 'from-purple-600/20 to-pink-600/10',
    glowColor: 'rgba(147, 51, 234, 0.3)',
    tech: ['Web Audio API', 'AWS S3', 'ElasticSearch'],
  },
  {
    id: 'ars-studio',
    emoji: '🎨',
    name: 'ARS Creator Studio',
    tagline: 'Built-In Video Editor',
    description:
      'A powerful in-app video editor with Nepali-specific filters, text overlays in Devanagari script, stickers, transitions, and auto-caption support.',
    status: 'idea',
    features: [
      'Devanagari text overlay',
      'Nepali-themed filters',
      'Multi-clip timeline',
      'Auto-caption (Nepali)',
      'Background remover',
      'Sticker library',
    ],
    color: 'from-blue-600/20 to-cyan-600/10',
    glowColor: 'rgba(59, 130, 246, 0.3)',
    tech: ['FFmpeg', 'TensorFlow.js', 'Canvas API'],
  },
  {
    id: 'ars-safe',
    emoji: '🔒',
    name: 'ARS SafeSpace',
    tagline: 'Content Safety & Moderation',
    description:
      'A robust content moderation system powered by AI, with human review, reporting tools, and community safety features tailored to Nepali cultural context.',
    status: 'idea',
    features: [
      'AI content moderation',
      'Community reporting',
      'Age-appropriate filters',
      'Privacy controls',
      'Anti-bullying system',
      'Safe mode for minors',
    ],
    color: 'from-green-600/20 to-teal-600/10',
    glowColor: 'rgba(34, 197, 94, 0.3)',
    tech: ['TensorFlow', 'Python', 'OpenCV', 'Firebase'],
  },
];

// ─── Status Badge ───────────────────────────────────────────────────────────
const statusConfig = {
  building: {
    label: '🔨 Currently Building',
    className: 'bg-red-600/20 border-red-600/40 text-red-400',
    dot: 'bg-red-400',
  },
  planned: {
    label: '📋 Planned',
    className: 'bg-blue-600/20 border-blue-600/40 text-blue-400',
    dot: 'bg-blue-400',
  },
  idea: {
    label: '💡 In Concept',
    className: 'bg-purple-600/20 border-purple-600/40 text-purple-400',
    dot: 'bg-purple-400',
  },
};

// ─── Product Card ────────────────────────────────────────────────────────────
function ProductCard({ product, index }: { product: Product; index: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);
  const status = statusConfig[product.status];

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setVisible(true); },
      { threshold: 0.05 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  return (
    <div
      ref={ref}
      className="product-card rounded-3xl p-6 sm:p-8 overflow-hidden group relative"
      style={{
        transition: `all 0.7s ease ${index * 100}ms`,
        opacity: visible ? 1 : 0,
        transform: visible ? 'translateY(0)' : 'translateY(40px)',
      }}
    >
      <div className={`absolute inset-0 bg-gradient-to-br ${product.color} opacity-0 group-hover:opacity-100 transition-opacity duration-500 rounded-3xl`} />

      <div className="relative z-10">
        {/* Header */}
        <div className="flex items-start justify-between mb-5">
          <div className="flex items-center gap-4">
            <div
              className="w-14 h-14 rounded-2xl flex items-center justify-center text-3xl shadow-lg"
              style={{ background: `linear-gradient(135deg, ${product.glowColor.replace('0.3', '0.2')}, rgba(255,255,255,0.03))`, border: `1px solid ${product.glowColor.replace('0.3', '0.15')}` }}
            >
              {product.emoji}
            </div>
            <div>
              <h3
                className="text-white font-black text-xl"
                style={{ fontFamily: 'Space Grotesk, sans-serif' }}
              >
                {product.name}
              </h3>
              <p className="text-white/40 text-sm">{product.tagline}</p>
            </div>
          </div>
        </div>

        {/* Status badge */}
        <div className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-full border text-xs font-semibold mb-4 ${status.className}`}>
          <div className={`w-1.5 h-1.5 rounded-full ${status.dot} ${product.status === 'building' ? 'animate-pulse' : ''}`} />
          {status.label}
        </div>

        {/* Description */}
        <p className="text-white/55 text-sm leading-relaxed mb-6">{product.description}</p>

        {/* Features */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mb-6">
          {product.features.map((feat) => (
            <div key={feat} className="flex items-center gap-2 text-white/60 text-xs">
              <CheckCircle2 className="w-3.5 h-3.5 text-green-400/70 flex-shrink-0" />
              {feat}
            </div>
          ))}
        </div>

        {/* Tech stack */}
        <div className="flex flex-wrap gap-1.5">
          {product.tech.map((t) => (
            <span
              key={t}
              className="text-[10px] font-mono px-2 py-1 rounded-md bg-white/5 border border-white/10 text-white/40"
            >
              {t}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── Products Page ────────────────────────────────────────────────────────────
export default function Products() {
  const buildingProducts = products.filter((p) => p.status === 'building');
  const plannedProducts = products.filter((p) => p.status === 'planned');
  const ideaProducts = products.filter((p) => p.status === 'idea');

  return (
    <div className="min-h-screen bg-[#0a0a0f]">
      {/* Background */}
      <div className="fixed inset-0 bg-grid opacity-20 pointer-events-none" />
      <div className="fixed top-0 left-0 right-0 h-[600px] pointer-events-none"
        style={{
          background: 'radial-gradient(ellipse 80% 50% at 50% 0%, rgba(220,38,38,0.08) 0%, transparent 70%)',
        }}
      />
      <div className="fixed top-1/4 left-1/4 w-96 h-96 bg-red-600/5 rounded-full blur-3xl pointer-events-none" />
      <div className="fixed bottom-1/4 right-1/4 w-64 h-64 bg-orange-500/5 rounded-full blur-3xl pointer-events-none" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-32 pb-24">
        {/* Back button */}
        <Link
          to="/"
          className="inline-flex items-center gap-2 text-white/40 hover:text-white text-sm mb-10 transition-colors duration-200 group"
        >
          <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform duration-200" />
          Back to Home
        </Link>

        {/* Page header */}
        <div className="text-center mb-16 space-y-5">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-red-600/10 border border-red-600/20 text-red-400 text-sm font-medium">
            <Rocket className="w-4 h-4" />
            ARS Product Suite
          </div>

          <h1
            className="text-4xl sm:text-5xl md:text-6xl font-black text-white"
            style={{ fontFamily: 'Space Grotesk, sans-serif' }}
          >
            What We're{' '}
            <span className="gradient-text">Building</span>
          </h1>

          <p className="text-white/50 text-base max-w-2xl mx-auto">
            ARS is more than one app — it's an entire ecosystem for Nepali creators.
            Every product below is being designed with Nepal in mind.
          </p>

          {/* Live days counter on products page */}
          <div className="inline-block mt-4">
            <div className="stat-card rounded-2xl px-8 py-6 flex flex-col items-center">
              <div className="flex items-center gap-2 mb-3">
                <div className="w-2 h-2 rounded-full bg-red-400 animate-pulse" />
                <span className="text-white/40 text-xs uppercase tracking-widest font-medium">Live Build Counter</span>
              </div>
              <DaysCounter showLabel={true} />
            </div>
          </div>
        </div>

        {/* ── Currently Building ── */}
        {buildingProducts.length > 0 && (
          <div className="mb-14">
            <div className="flex items-center gap-3 mb-6">
              <div className="flex items-center gap-2 text-red-400 font-bold text-lg" style={{ fontFamily: 'Space Grotesk, sans-serif' }}>
                <Zap className="w-5 h-5" />
                Currently Building
              </div>
              <div className="flex-1 h-px bg-gradient-to-r from-red-600/40 to-transparent" />
              <span className="text-white/20 text-xs">LIVE</span>
              <div className="w-2 h-2 rounded-full bg-red-400 animate-pulse" />
            </div>
            <div className="grid grid-cols-1 gap-6">
              {buildingProducts.map((p, i) => (
                <ProductCard key={p.id} product={p} index={i} />
              ))}
            </div>
          </div>
        )}

        {/* ── Planned ── */}
        {plannedProducts.length > 0 && (
          <div className="mb-14">
            <div className="flex items-center gap-3 mb-6">
              <div className="flex items-center gap-2 text-blue-400 font-bold text-lg" style={{ fontFamily: 'Space Grotesk, sans-serif' }}>
                <Clock className="w-5 h-5" />
                Planned Features
              </div>
              <div className="flex-1 h-px bg-gradient-to-r from-blue-600/40 to-transparent" />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {plannedProducts.map((p, i) => (
                <ProductCard key={p.id} product={p} index={i} />
              ))}
            </div>
          </div>
        )}

        {/* ── Ideas / Concepts ── */}
        {ideaProducts.length > 0 && (
          <div className="mb-14">
            <div className="flex items-center gap-3 mb-6">
              <div className="flex items-center gap-2 text-purple-400 font-bold text-lg" style={{ fontFamily: 'Space Grotesk, sans-serif' }}>
                <Star className="w-5 h-5" />
                Concepts & Ideas
              </div>
              <div className="flex-1 h-px bg-gradient-to-r from-purple-600/40 to-transparent" />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {ideaProducts.map((p, i) => (
                <ProductCard key={p.id} product={p} index={i} />
              ))}
            </div>
          </div>
        )}

        {/* Bottom CTA */}
        <div className="relative bg-gradient-to-br from-red-950/40 to-orange-950/20 border border-red-600/20 rounded-3xl p-10 text-center overflow-hidden mt-6">
          <div className="absolute inset-0 bg-gradient-to-br from-red-600/5 to-orange-500/5" />
          <div className="relative z-10 space-y-5">
            <div className="text-4xl">🇳🇵</div>
            <h3
              className="text-2xl sm:text-3xl font-black text-white"
              style={{ fontFamily: 'Space Grotesk, sans-serif' }}
            >
              Support Nepal's Own Platform
            </h3>
            <p className="text-white/50 text-sm max-w-lg mx-auto">
              A 17-year-old Nepali student is building all of this alone.
              Join the waitlist, spread the word, and help ARS become Nepal's biggest platform.
            </p>
            <Link
              to="/#join"
              className="inline-flex items-center gap-2 btn-primary px-8 py-3.5 rounded-2xl text-sm font-bold text-white"
            >
              <span>🚀 Join the Waitlist</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
