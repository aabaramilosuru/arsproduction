import { Link } from 'react-router-dom';
import { Play, Heart } from 'lucide-react';

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="relative border-t border-white/5 bg-black/40 backdrop-blur-xl">
      {/* Top divider glow */}
      <div className="section-divider mb-0" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10 mb-12">
          {/* Brand */}
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-red-600 to-orange-500 flex items-center justify-center shadow-lg glow-red">
                <Play className="w-5 h-5 text-white fill-white" />
              </div>
              <div>
                <span className="text-xl font-bold gradient-text" style={{ fontFamily: 'Space Grotesk, sans-serif' }}>
                  ARS
                </span>
                <p className="text-[10px] text-white/40 leading-none tracking-widest uppercase">Nepal</p>
              </div>
            </div>
            <p className="text-white/50 text-sm leading-relaxed">
              Aaba Ramilo Suru — Nepal's own short-form video platform.
              Created by a Nepali student, for Nepali creators.
            </p>
            <div className="flex items-center gap-1 text-2xl">
              🇳🇵
              <span className="text-white/30 text-xs ml-1">Made with pride in Nepal</span>
            </div>
          </div>

          {/* Links */}
          <div className="space-y-4">
            <h4 className="text-white font-semibold text-sm tracking-wider uppercase">Quick Links</h4>
            <div className="space-y-2">
              {[
                { label: 'Home', to: '/' },
                { label: 'Products', to: '/products' },
                { label: 'Features', to: '/#features' },
                { label: 'About Developer', to: '/#about' },
              ].map((link) => (
                <Link
                  key={link.label}
                  to={link.to}
                  className="block text-white/40 hover:text-red-400 text-sm transition-colors duration-200"
                >
                  → {link.label}
                </Link>
              ))}
            </div>
          </div>

          {/* Contact / Social */}
          <div className="space-y-4">
            <h4 className="text-white font-semibold text-sm tracking-wider uppercase">Connect</h4>
            <p className="text-white/40 text-sm">
              Follow the journey of building Nepal's first homegrown video platform.
            </p>
            <div className="flex gap-3">
              {[
                { emoji: '📸', label: 'Instagram' },
                { emoji: '🐦', label: 'Twitter/X' },
                { emoji: '▶️', label: 'YouTube' },
                { emoji: '💻', label: 'GitHub' },
              ].map(({ emoji, label }) => (
                <button
                  key={label}
                  title={label}
                  className="w-9 h-9 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-white/50 hover:text-red-400 hover:border-red-600/40 hover:bg-red-600/10 transition-all duration-200 text-base"
                >
                  {emoji}
                </button>
              ))}
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
              <span className="text-green-400/70 text-xs">Actively building</span>
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="section-divider mb-8" />
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-white/30 text-sm flex items-center gap-1.5">
            © {currentYear} ARS Nepal. Built with{' '}
            <Heart className="w-3.5 h-3.5 text-red-500 fill-red-500" />
            {' '}in Nepal by{' '}
            <span className="text-white/60 font-medium">Roshan Shrestha</span>
          </p>
          <div className="flex items-center gap-4 text-white/20 text-xs">
            <span>Privacy Policy</span>
            <span>·</span>
            <span>Terms of Service</span>
            <span>·</span>
            <span className="text-red-400/60">🇳🇵 Nepal</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
